
let flag = ''; // Initialize flag variable


function myfunc_3() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b1').value = 'X';
        document.getElementById('b1').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b1').value = '0';
        document.getElementById('b1').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }
}

function myfunc_4() {
  console.log("innn",flag)
    if (flag === 'X' || flag === '') {
        document.getElementById('b2').value = 'X';
        document.getElementById('b2').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b2').value = '0';
        document.getElementById('b2').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }
}

function myfunc_5() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b3').value = 'X';
        document.getElementById('b3').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b3').value = '0';
        document.getElementById('b3').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }
}

function myfunc_6() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b4').value = 'X';
        document.getElementById('b4').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b4').value = '0';
        document.getElementById('b4').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }
}

function myfunc_7() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b5').value = 'X';
        document.getElementById('b5').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b5').value = '0';
        document.getElementById('b5').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }
}
function myfunc_8() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b6').value = 'X';
        document.getElementById('b6').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b6').value = '0';
        document.getElementById('b6').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }

}

function myfunc_9() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b7').value = 'X';
        document.getElementById('b7').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b7').value = '0';
        document.getElementById('b7').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }

}



function myfunc_10() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b8').value = 'X';
        document.getElementById('b8').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b8').value = '0';
        document.getElementById('b8').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }

}


function myfunc_11() {
    if (flag === 'X' || flag === '') {
        document.getElementById('b9').value = 'X';
        document.getElementById('b9').disabled = true;
        flag = '0'; // Update flag to '0' after printing 'X'
    }
    else if (flag === '0') {
        document.getElementById('b9').value = '0';
        document.getElementById('b9').disabled = true;
        flag = 'X'; // Update flag to 'X' after printing '0'
    }

}

function chkRows(){
if ( (document.getElementById('b1').value === 'X' && document.getElementById('b4').value === 'X' && document.getElementById('b7').value === 'X')||(
    document.getElementById('b1').value === '0' && document.getElementById('b4').value === '0' && document.getElementById('b7').value === '0'
    )||
   (document.getElementById('b2').value === 'X' && document.getElementById('b5').value === 'X' && document.getElementById('b8').value === 'X')||(
    document.getElementById('b2').value === '0' && document.getElementById('b5').value === '0' && document.getElementById('b8').value === '0'
    )||(
(document.getElementById('b3').value === 'X' && document.getElementById('b6').value === 'X' && document.getElementById('b9').value === 'X')||(
    document.getElementById('b3').value === '0' && document.getElementById('b6').value === '0' && document.getElementById('b9').value === '0'
    )


)
   
   ){
  
  return true;
  
}
  return false
  
}


function chkDaigonal(){
if ( (document.getElementById('b1').value === 'X' && document.getElementById('b5').value === 'X' && document.getElementById('b9').value === 'X')||(
    document.getElementById('b1').value === '0' && document.getElementById('b5').value === '0' && document.getElementById('b9').value === '0'
    )||
   (document.getElementById('b3').value === 'X' && document.getElementById('b5').value === 'X' && document.getElementById('b7').value === 'X')||(
    document.getElementById('b3').value === '0' && document.getElementById('b5').value === '0' && document.getElementById('b7').value === '0'
    )   
   ){
  
  return true;
  
}
  return false
  
}






function chkColumns(){
if (


(document.getElementById('b1').value === 'X' && document.getElementById('b2').value === 'X' && document.getElementById('b3').value === 'X')
||(
    document.getElementById('b1').value === '0' && document.getElementById('b2').value === '0' && document.getElementById('b3').value === '0'
    )||
(document.getElementById('b4').value === 'X' && document.getElementById('b5').value === 'X' && document.getElementById('b6').value === 'X')||(
    document.getElementById('b4').value === '0' && document.getElementById('b5').value === '0' && document.getElementById('b6').value === '0'
    ) ||
    (document.getElementById('b7').value === 'X' && document.getElementById('b8').value === 'X' && document.getElementById('b9').value === 'X')||(
    document.getElementById('b7').value === '0' && document.getElementById('b8').value === '0' && document.getElementById('b9').value === '0'
    )





)
  
  
  
  {
  
  return true;
  
}
  return false
  
}



function myfunc() {
    if (
    chkColumns()||chkRows()||chkDaigonal()
    ) {
let p = document.createElement('p');
      let ui = document.querySelector('.ui');
        console.log("innn",ui);
        let winnerFlag = flag === 'X' ? '0' : 'X';
let content = document.createTextNode(`Player ${winnerFlag} is winner`);
p.appendChild(content);
      document.classList.add('winner')
      p.style.color='red'
        ui.insertAdjacentElement('beforebegin', p);
      setTimeout(()=>{
        p.style.color='green'
      },500)
        setTimeout(()=>{
        p.style.color='green'
      },1000)
    }
}
